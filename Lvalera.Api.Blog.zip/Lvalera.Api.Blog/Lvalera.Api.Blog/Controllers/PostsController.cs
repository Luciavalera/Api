﻿using Lvalera.Api.Blog.Model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lvalera.Api.Blog.Controllers
{
    public class PostsController : Controller
    {

        //Propiedades
        public List<Posts> Posts { get; set; }

        //Constructor
        public PostsController()
        {
            Posts = new List<Posts>();
            Posts.Add(new Posts(1, "Covid-19", "El Covid-19 llegó a España en 2020"));
            Posts.Add(new Posts(2, "Subida de la luz", "Este ultimo mes la luz ha aumentado el doble en comparación al mes anterior"));
            Posts.Add(new Posts(3, "BlackFriday", "Esta semana han subido las ventes gracias al BlackFriday"));
        }

        //Metodos
        //GETall
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(Posts);
        }

        //GET
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                return Ok(Posts.Find (posts => posts.Id == id));
            }
            catch
            {
                return NotFound("NOT FOUND");
            }
        }

        [HttpGet("tittle/{tittle}")]
        public IActionResult GetTittle(string tittle)
        {
            var result = Posts.FirstOrDefault(posts => posts.Tittle == tittle);

            if(result == null)
            {
                return NotFound("NOT FOUND");
            }

            return Ok(result);
        }

        [HttpGet("body/{body}")]
        public Posts GetBody(string body)
        {
            return Posts.FirstOrDefault(posts => posts.Body == body);
        }

        //POST
        [HttpPost("{id}")]
        public IActionResult Post([FromBody] Posts value)
        {
            Posts.Add(value);
            return Ok();
        }

        //PUT
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Posts value)
        {
            var PostToUpdate = Posts.Single(Posts => Posts.Id == id);
            Posts.Remove(PostToUpdate);
            Posts.Add(PostToUpdate);
            return Ok();
        }

        //DELETE
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var p = Posts.FirstOrDefault(Posts => Posts.Id == id);
            if(p != null)
            {
                Posts.Remove(p);
            }

            return Ok();
        }
    }
}
