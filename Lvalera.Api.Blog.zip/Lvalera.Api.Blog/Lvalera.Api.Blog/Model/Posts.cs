﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lvalera.Api.Blog.Model
{
    public class Posts
    {
        public int Id { get; set; }
        public string Tittle { get; set; }
        public string Body { get; set; }
        public string ShortBody { get; set; }

        public Posts(int id, string tittle, string body)
        {
            Id = id;
            Tittle = tittle;
            Body = body;
            
            if(body.Length > 100)
            {
                ShortBody = body.Substring(0, 100) + "...";
            }
            else
            {
                ShortBody = body;
            }
        }
    }
}
